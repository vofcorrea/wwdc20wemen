import Foundation
import SpriteKit
import UIKit
import PlaygroundSupport

public class InitialScene: SKScene {
    
    //Creating next scene
    public var nextScene: MyScene?
    
    //Creating the background da initianlScene
    public var background = SKSpriteNode(imageNamed: "scene/scene1")
    
    //Constructor
    public override init(size: CGSize) {
        super.init(size: size)
    }
    
    //Standard code - must have
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    //1 - background configuration
    override public func sceneDidLoad() {
        background.setScale(0.5)
        background.position = CGPoint(x: frame.size.width/2, y: frame.size.height/2)
        addChild(background)
    }

    //2 - backgruond in scene
    public override func didMove(to view: SKView) {
        nextScene = MyScene(size: view.bounds.size)
        nextScene!.backgroundColor = UIColor.white
        
        //-------Background scene-------

        //Creating layer of background
        let bgBack = SKSpriteNode(imageNamed: "background/background.png")

        //Creating a variable for image position
        let pos = CGPoint (x: view.frame.size.width*0.5, y: view.frame.size.height*0.5)

        //Creating a variable list
        var layers = [SKSpriteNode]()

        //Adjust layer position
        bgBack.zPosition = 0

        //Background image position
        bgBack.position = CGPoint (x: 0.0, y: 0.0)
        bgBack.zPosition = -10

        //Put vector
        layers.append(contentsOf: ([bgBack]))

        //Putting the scene
        for layer in layers {
            // 1.
            layer.texture?.filteringMode = .nearest
            // 2.
            layer.position = pos
            // 3.
            layer.setScale(0.5)
            // 4.
            nextScene!.addChild(layer)
        }
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view?.presentScene(nextScene)
    }
}
