import Foundation
import UIKit
import SpriteKit
import PlaygroundSupport


//Class to put the frame numbers
public class FrameNode: SKSpriteNode {
    var animationFrames = 0
    var folderName = ""
    var speedAnimation = 0.0
    var pieceOfStory = ""
    var about = ""
}

public class Story{
    var pieceOfStory = SKSpriteNode(imageNamed: "story/pieceOfStory1")
    var activated = false
}

public class AboutStory{
    var about = SKSpriteNode(imageNamed: "story/story")
    var active = false
}

//-------Scene class-------
public class MyScene: SKScene {
    
    //Add the object to the scene
    public var vase = FrameNode(imageNamed: "vase/vase1.png")
    public var spaceship = FrameNode(imageNamed: "spaceship/spaceship1.png")
    public var horizontalBook = FrameNode(imageNamed: "horizontalBook/horizontalBook1.png")
    public var verticalBook = FrameNode(imageNamed: "verticalBook/verticalBook1.png")
    public var pictureFrame = FrameNode(imageNamed: "pictureFrame/pictureFrame1.png")
    public var tree = FrameNode(imageNamed: "tree/tree1.png")
    public var nobel = FrameNode(imageNamed: "nobel/nobel1.png")
    public var pencil = FrameNode(imageNamed: "pencil/pencil1.png")
    public var car = FrameNode(imageNamed: "car/car1.png")
    public var plant = FrameNode(imageNamed: "plant/plant1.png")
    public var sneakers = FrameNode(imageNamed: "sneakers/sneakers1.png")
    public var dog = FrameNode(imageNamed: "dog/dog1.png")
    public var masp = FrameNode(imageNamed: "masp/masp1.png")
    public var astronaut = FrameNode(imageNamed: "astronaut/astronaut1.png")
    public var samambaia = FrameNode(imageNamed: "samambaia/samambaia1.png")
    public var me = FrameNode(imageNamed: "me/me1.png")
    public var light = FrameNode(imageNamed: "light/light1.png")
    public var myImage = Story()
    public var buttonAbout = FrameNode(imageNamed: "buttonAbout/buttonAbout.png")
    public var myStory = AboutStory ()
    
    //Constructor
    public override init(size: CGSize) {
        super.init(size: size)
    }
    
    //Standard code - must have
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func sceneDidLoad() {
        print("TESTE")
        
        
        //-------Add object-------
        
        //Object position
        vase.position = CGPoint(x: 470.0, y: 157.0)
        spaceship.position = CGPoint(x: 84.0, y: 334.5)
        horizontalBook.position = CGPoint(x: 138.0, y: 303.5)
        verticalBook.position = CGPoint(x: 53.5, y: 307.5)
        pictureFrame.position = CGPoint(x: 41.5, y: 263.0)
        tree.position = CGPoint(x: 94.0, y: 251.5)
        nobel.position = CGPoint(x: 138.0, y: 250.5)
        pencil.position = CGPoint(x: 55.0, y: 202.0)
        car.position = CGPoint(x: 114.0, y: 201.5)
        plant.position = CGPoint(x: 40.5, y: 90.0)
        sneakers.position = CGPoint(x: 178.5, y: 50.0)
        dog.position = CGPoint(x: 441.5, y: 46.0)
        masp.position = CGPoint(x: 228.5, y: 287.5)
        astronaut.position = CGPoint(x: 380.5, y: 287.5)
        samambaia.position = CGPoint(x: 467.5, y: 312.5)
        me.position = CGPoint(x: 305.5, y: 184.0)
        light.position = CGPoint(x: 305.0, y: 343.5)
        myImage.pieceOfStory.position = CGPoint(x: 256.5, y: -35)
        buttonAbout.position = CGPoint(x: 8.0, y: 360.0)
        myStory.about.position = CGPoint(x: -128.0, y: 193.0)
        
        
        //Variable name
        vase.folderName = "vase"
        spaceship.folderName = "spaceship"
        horizontalBook.folderName = "horizontalBook"
        verticalBook.folderName = "verticalBook"
        pictureFrame.folderName = "pictureFrame"
        tree.folderName = "tree"
        nobel.folderName = "nobel"
        pencil.folderName = "pencil"
        car.folderName = "car"
        plant.folderName = "plant"
        sneakers.folderName = "sneakers"
        dog.folderName = "dog"
        masp.folderName = "masp"
        astronaut.folderName = "astronaut"
        samambaia.folderName = "samambaia"
        me.folderName = "me"
        light.folderName = "light"
        
        //Number of frames that the animation needs
        vase.animationFrames = 9
        spaceship.animationFrames = 9
        horizontalBook.animationFrames = 5
        verticalBook.animationFrames = 7
        pictureFrame.animationFrames = 6
        tree.animationFrames = 9
        nobel.animationFrames = 8
        pencil.animationFrames = 10
        car.animationFrames = 6
        plant.animationFrames = 6
        sneakers.animationFrames = 8
        dog.animationFrames = 3
        masp.animationFrames = 9
        astronaut.animationFrames = 5
        samambaia.animationFrames = 6
        me.animationFrames = 11
        light.animationFrames = 1
        buttonAbout.animationFrames = 1
        
        //Animation speed
        vase.speedAnimation = 0.2
        spaceship.speedAnimation = 0.1
        horizontalBook.speedAnimation = 0.1
        verticalBook.speedAnimation = 0.1
        pictureFrame.speedAnimation = 0.1
        tree.speedAnimation = 0.2
        nobel.speedAnimation = 0.1
        pencil.speedAnimation = 0.1
        car.speedAnimation = 0.2
        plant.speedAnimation = 0.2
        sneakers.speedAnimation = 0.2
        dog.speedAnimation = 0.5
        masp.speedAnimation = 0.1
        astronaut.speedAnimation = 0.1
        samambaia.speedAnimation = 0.1
        me.speedAnimation = 0.1
        light.speedAnimation = 0.2
        
        //Object size
        vase.setScale(0.5)
        spaceship.setScale(0.5)
        horizontalBook.setScale(0.5)
        verticalBook.setScale(0.5)
        pictureFrame.setScale(0.5)
        tree.setScale(0.5)
        nobel.setScale(0.5)
        pencil.setScale(0.5)
        car.setScale(0.5)
        plant.setScale(0.5)
        sneakers.setScale(0.5)
        dog.setScale(0.5)
        masp.setScale(0.5)
        astronaut.setScale(0.5)
        samambaia.setScale(0.5)
        me.setScale(0.5)
        light.setScale(0.5)
        myImage.pieceOfStory.setScale(0.5)
        buttonAbout.setScale(0.5)
        myStory.about.setScale(0.5)
        
        //Object story
        spaceship.pieceOfStory = "story/pieceOfStory2"
        horizontalBook.pieceOfStory = "story/pieceOfStory2"
        verticalBook.pieceOfStory = "story/pieceOfStory2"
        pictureFrame.pieceOfStory = "story/pieceOfStory1"
        tree.pieceOfStory = "story/pieceOfStory1"
        nobel.pieceOfStory = "story/pieceOfStory3"
        pencil.pieceOfStory = "story/pieceOfStory4"
        car.pieceOfStory = "story/pieceOfStory6"
        sneakers.pieceOfStory = "story/pieceOfStory5"
        masp.pieceOfStory = "story/pieceOfStory4"
        astronaut.pieceOfStory = "story/pieceOfStory6"
        me.pieceOfStory = "story/pieceOfStory7"
        buttonAbout.about = "story/story"
        
        //Putting in scene
        self.addChild(vase)
        self.addChild(spaceship)
        self.addChild(horizontalBook)
        self.addChild(verticalBook)
        self.addChild(pictureFrame)
        self.addChild(tree)
        self.addChild(nobel)
        self.addChild(pencil)
        self.addChild(car)
        self.addChild(plant)
        self.addChild(sneakers)
        self.addChild(dog)
        self.addChild(masp)
        self.addChild(astronaut)
        self.addChild(samambaia)
        self.addChild(me)
        self.addChild(light)
        self.addChild(myImage.pieceOfStory)
        self.addChild(buttonAbout)
        self.addChild(myStory.about)
    }
    
    //Click condition
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location (in: self)
            let touchedNode = atPoint(location);
            
            //Identifying the node touched
            guard let frameTouchedNode = touchedNode as? FrameNode else {
                if myImage.activated {
                    myImage.activated = false
                    let animationHistoria = SKAction.moveTo(y: -35.0, duration: 0.5)
                    myImage.pieceOfStory.run(animationHistoria)
                }
                
                if myStory.active {
                    myStory.active = false
                    let animationHistoriaToda = SKAction.moveTo(x: -128.0, duration: 0.5)
                    myStory.about.run(animationHistoriaToda)
                }
                return }
            
            //action to exchange frames - animation
            var spritesCharacter = [SKTexture]()
            
            //1. List and cycle through all sprites
            for index in 1...frameTouchedNode.animationFrames{
            //2. Find Sprites inside the folder
                let spriteFound = SKTexture(imageNamed: "\(frameTouchedNode.folderName)/\(frameTouchedNode.folderName)\(index).png")
            //3. Adds the spite found in the list
                spritesCharacter.append(spriteFound)
            }
            
            //Putting condition for the buttons to work
            if frameTouchedNode.animationFrames > 1{
                //Set action to animate texture of the texture array
                let animate = SKAction.animate (with: spritesCharacter, timePerFrame: frameTouchedNode.speedAnimation)
                //Start animation
                frameTouchedNode.run(animate)
            }
            
            //Animation piece of story
            //Object enter the scene
            if myImage.activated{
                //Variable validate
                myImage.activated = false
                //Location and time of the object to move
                let animationStory = SKAction.moveTo(y: -35.0, duration: 0.5)
                myImage.pieceOfStory.run(animationStory)
            } else {
                if frameTouchedNode.pieceOfStory != ""{
                    myImage.activated = true
                    myImage.pieceOfStory.texture = SKTexture(imageNamed: frameTouchedNode.pieceOfStory)
                    let animationStory = SKAction.moveTo(y: 30.0, duration: 0.5)
                    myImage.pieceOfStory.run(animationStory)
                }
            }

            //Animation about
            //Object enter the scene
            if myStory.active{
                //Variable validate
                myStory.active = false
                //Location and time of the object to move
                let animationAbout = SKAction.moveTo(x: -128.0, duration: 0.5)
                myStory.about.run(animationAbout)
            }else if frameTouchedNode.about != ""{
                myStory.active = true
                myStory.about.texture = SKTexture(imageNamed: frameTouchedNode.about)
                let animationAbout = SKAction.moveTo(x: 128.0, duration: 0.5)
                myStory.about.run(animationAbout)
            }
        }
    }
    //Code to help me organize the objects in the scene
    //              public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    //                 let touch = touches.first!
    //                 let location = touch.location (in: self)
    //                 let touchedNode = atPoint(location);
    //                 touchedNode.position = location
    //                      print(location)
    //                }
}
