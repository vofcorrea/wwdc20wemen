import UIKit
import SpriteKit
import PlaygroundSupport

/*:
 ## Me in other women
 **by Vitória Corrêa for WWDC20**
 
 
 
 ### Idea
 From the beginning I wanted a playground to tell my story so that people could get to know me and learn a little about my trajectory. When I started thinking about everything I lived, all my difficulties, dreams and goals for the future, I realized that there were several women who somehow helped me to be who I am today.
 
 I decided that I wanted to honor them on my playground and tell my life story through them, who have already played a very important role.
 I wanted to be able to tell my past, present and what I plan for the future. So divide my project into three steps:
 
 - The first stage told my past through these women, how our stories created a connection and how important and essential they were for me.
 - The second stage would be the scene that would take place in a place that most represents me today. Today I live alone in Brasília and I have a very objects in my house, each one has a special meaning, some remind me of my family who live in another state, my friends  and others with some special meaning.I'll show my present through my favorite place in my home: the living room.
 - The third stage would be my future. In addition to wanting to be an illustrator and be passionate about animations, I really want to be a designer who programs. So give me the challenge of making my playground programmed in Swift where I implement animations.
 
 
 
 ### Developer
 After deciding what it would be like my playground, the first challenge came, we are in quarantined by Covid-19. How to learn a developer and work from home alone? The development of this interactive scene showed me that I am capable of many things, things that I didn't even know I would be. Organizing and dividing my time in design and development, learning a programming language, a question that because I didn't know, I have no idea how I was going to cope and how long I was going to be able to execute and a totally unusual situation due to a pandemic.
 
 Keep a healthy mind at this point, manage the time to accomplish everything I would have planned. Keeping my thoughts on this project helped me to blur about the pandemic and be fine.
 
 When I decided the graphic style for the project, I choose the one that most represents me, I am passionate about the flat style and opaque colors. I really wanted the whole playground to have my personality.
 
 Soon I started to create all the objects that represent the connection of these women with me, in the creation process, I was able to feel their strength and that motivated and captivated me even more to follow the project.
 
 My second challenge came, I opened Xcode, where to start? So I start studying Swift, start the basics. Gradually I began to venture into the new language learned.
 Start with the animation part, I wanted to understand how to animate a Frame by Frame object in a playground. Then I passed to animating more than one object in the scene by through touch.
 
 I had already understood how the code worked and managed to achieve 80% of what was planned. Now, all the objects needed to be placed on the scene, as I had prototyped and my third and biggest challenge came up: discovering that the coordinates of x and y in the playground were different from the prototyping program, adobe XD, as I should do to be like I plan without having to test values ​​until I got close to what I wanted?
 
 With yet another challenge, I got a solution where it would be feasible. **After that challenge, I realized that I was enjoying programming and loving the feeling of when a problem is solved. Wow! How satisfying to think about something and be able to execute, even more when it comes to the front end, my new passion.**
 
 
 
 ### Result
 To complete the project, refine the illustrations and code, so i finished. The moment I tested it and saw the result of all my effort, I saw that it is very worthwhile, I felt enormous happiness! Having had several difficulties along this path and finding solutions through my dedication and study showed me that I have the strength and perseverance to set even greater goals in my life.
 
 The most amazing thing about this project was  he showed me that i'm capable, that I has strength and perseverance like all the women who I portrayed telling my story in the playground. Seeing that I'm becoming a woman like them, creating my space and fighting for my dreams how they, have caused me countless rewards. I knew in that moment that I was going the right way, I got to see more of them in me. Finding out i'm supported by amazing people was the best reward I could have in this playground.
 */


//-------Scene setting-------

//View size
let sizeOfView = CGRect (x: 0, y: 0, width: 513, height: 384)

//Scene view
let view = SKView (frame: sizeOfView)

//Scene size
let scene = InitialScene(size: view.bounds.size)

//Backrgound color
scene.backgroundColor = UIColor.white

//Putting view in scene
view.presentScene(scene)

//Putting view in playground
PlaygroundPage.current.liveView = view




